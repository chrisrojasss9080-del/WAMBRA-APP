#!/usr/bin/env python3
"""
Genera todos los íconos PNG necesarios para WAMBRA PWA
usando solo Pillow (sin dependencias externas).
"""

import os
from PIL import Image, ImageDraw, ImageFont

SIZES = [72, 96, 128, 144, 152, 192, 384, 512]
OUTPUT_DIR = "icons"
os.makedirs(OUTPUT_DIR, exist_ok=True)

# Colores de la app
BG      = (13,  13,  13)      # #0D0D0D
PURPLE  = (139, 127, 255)     # #8B7FFF
PURPLE2 = (106, 95,  212)     # #6A5FD4
TEAL    = (13,  228, 192)     # #0de4c0
WHITE   = (245, 245, 240)     # #F5F5F0

def draw_icon(size):
    img  = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    pad  = size * 0.06

    # ── Fondo redondeado ────────────────────────────────────
    radius = size * 0.22
    draw.rounded_rectangle([pad, pad, size-pad, size-pad],
                           radius=radius, fill=BG)

    # ── Gradiente simulado (círculo decorativo) ─────────────
    cx, cy = size/2, size/2
    for i in range(int(size*0.35), 0, -1):
        alpha = int(40 * (i / (size*0.35)))
        draw.ellipse([cx-i, cy-i-size*0.1, cx+i, cy+i-size*0.1],
                     fill=(*PURPLE2, alpha))

    # ── Letras "W" ──────────────────────────────────────────
    # Dibujamos "W" con líneas (no dependemos de fuentes externas)
    m    = size * 0.15       # margen lateral
    top  = size * 0.28
    bot  = size * 0.68
    mid  = size * 0.52
    lw   = max(2, int(size * 0.055))

    pts = [
        (m,          top),
        (size*0.31,  bot),
        (size*0.50,  mid),
        (size*0.69,  bot),
        (size - m,   top),
    ]
    draw.line(pts, fill=WHITE, width=lw, joint="curve")

    # Subrayado teal
    bar_y  = size * 0.75
    bar_h  = max(2, int(size * 0.045))
    bar_x1 = size * 0.20
    bar_x2 = size * 0.80
    draw.rounded_rectangle([bar_x1, bar_y, bar_x2, bar_y+bar_h],
                           radius=bar_h//2, fill=TEAL)

    # Punto decorativo teal (esquina superior derecha del ícono)
    dot_r = size * 0.06
    dot_x = size * 0.76
    dot_y = size * 0.22
    draw.ellipse([dot_x-dot_r, dot_y-dot_r, dot_x+dot_r, dot_y+dot_r],
                 fill=TEAL)

    return img

for s in SIZES:
    icon = draw_icon(s)
    path = os.path.join(OUTPUT_DIR, f"icon-{s}.png")
    icon.save(path, "PNG")
    print(f"✓ Generado {path}")

print("\n¡Todos los íconos creados exitosamente!")
