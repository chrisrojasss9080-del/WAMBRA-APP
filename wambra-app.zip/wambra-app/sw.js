// ═══════════════════════════════════════════════════════════
//  WAMBRA - Service Worker
//  Versión: 1.0.0
//  Estrategia: Cache-first para assets, Network-first para datos
// ═══════════════════════════════════════════════════════════

const CACHE_NAME = 'wambra-v1';
const CACHE_STATIC = 'wambra-static-v1';
const CACHE_FONTS  = 'wambra-fonts-v1';

// Archivos que se cachean inmediatamente al instalar el SW
const STATIC_ASSETS = [
  './',
  './index.html',
  './manifest.json',
  './icons/icon-192.png',
  './icons/icon-512.png'
];

// Fuentes de Google que queremos cachear
const FONT_ORIGINS = [
  'https://fonts.googleapis.com',
  'https://fonts.gstatic.com'
];

// ─── INSTALL ────────────────────────────────────────────────
// Se dispara cuando el navegador descarga el SW por primera vez.
// Pre-cacheamos todos los archivos estáticos esenciales.
self.addEventListener('install', event => {
  console.log('[SW] Instalando WAMBRA Service Worker...');
  event.waitUntil(
    caches.open(CACHE_STATIC).then(cache => {
      console.log('[SW] Pre-cacheando archivos estáticos');
      return cache.addAll(STATIC_ASSETS);
    }).then(() => {
      // Forzar que este SW tome control inmediatamente
      // sin esperar a que el usuario recargue la página
      return self.skipWaiting();
    })
  );
});

// ─── ACTIVATE ───────────────────────────────────────────────
// Se dispara cuando el SW toma control. Aquí limpiamos caches viejos.
self.addEventListener('activate', event => {
  console.log('[SW] Activando WAMBRA Service Worker...');
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames
          .filter(name => name !== CACHE_STATIC && name !== CACHE_FONTS)
          .map(name => {
            console.log('[SW] Eliminando cache viejo:', name);
            return caches.delete(name);
          })
      );
    }).then(() => {
      // Tomar control de todas las pestañas abiertas inmediatamente
      return self.clients.claim();
    })
  );
});

// ─── FETCH ──────────────────────────────────────────────────
// Intercepta TODAS las peticiones de red que hace la app.
self.addEventListener('fetch', event => {
  const { request } = event;
  const url = new URL(request.url);

  // ── Fuentes de Google: Cache-first con fallback a red ──
  if (FONT_ORIGINS.some(origin => url.origin === new URL(origin).origin)) {
    event.respondWith(
      caches.open(CACHE_FONTS).then(cache =>
        cache.match(request).then(cached => {
          if (cached) {
            console.log('[SW] Fuente desde cache:', url.pathname);
            return cached;
          }
          return fetch(request).then(response => {
            // Solo cacheamos respuestas válidas
            if (response && response.status === 200) {
              cache.put(request, response.clone());
            }
            return response;
          });
        })
      )
    );
    return;
  }

  // ── Archivos locales: Cache-first con fallback a red ──
  if (url.origin === self.location.origin) {
    event.respondWith(
      caches.match(request).then(cached => {
        if (cached) {
          console.log('[SW] Sirviendo desde cache:', url.pathname);
          return cached;
        }

        // No está en cache → buscar en red y guardar para la próxima
        return fetch(request).then(response => {
          if (!response || response.status !== 200 || response.type === 'opaque') {
            return response;
          }
          const responseToCache = response.clone();
          caches.open(CACHE_STATIC).then(cache => {
            cache.put(request, responseToCache);
          });
          return response;
        }).catch(() => {
          // Sin conexión y sin cache → mostrar página offline
          if (request.destination === 'document') {
            return caches.match('./index.html');
          }
        });
      })
    );
    return;
  }

  // ── Todo lo demás: simplemente ir a la red ──
  event.respondWith(fetch(request).catch(() => {
    // Silenciar errores de red para requests no críticos
  }));
});

// ─── BACKGROUND SYNC (futuro) ────────────────────────────────
// Cuando haya conexión, sincronizar datos pendientes
self.addEventListener('sync', event => {
  if (event.tag === 'sync-movimientos') {
    console.log('[SW] Background sync: movimientos');
    // Aquí iría la lógica de sincronización con backend
  }
});

// ─── PUSH NOTIFICATIONS (futuro) ────────────────────────────
// Para recordatorios de ahorro o metas
self.addEventListener('push', event => {
  if (!event.data) return;
  const data = event.data.json();
  self.registration.showNotification(data.title || 'WAMBRA', {
    body: data.body || '¡Recuerda registrar tus movimientos de hoy!',
    icon: './icons/icon-192.png',
    badge: './icons/icon-72.png',
    vibrate: [100, 50, 100],
    data: { url: data.url || './' }
  });
});

self.addEventListener('notificationclick', event => {
  event.notification.close();
  event.waitUntil(
    clients.openWindow(event.notification.data.url || './')
  );
});
