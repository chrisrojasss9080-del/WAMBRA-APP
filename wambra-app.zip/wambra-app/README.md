# WAMBRA — App de Finanzas para Jóvenes 💜

App de finanzas personales para adolescentes ecuatorianos. Funciona como **PWA (Progressive Web App)**, lo que significa que se puede instalar en el celular como si fuera una app nativa, sin necesidad de App Store ni Play Store.

---

## 📁 Estructura de archivos

```
wambra-app/
├── index.html        ← La app completa
├── manifest.json     ← Metadatos para que sea instalable
├── sw.js             ← Service Worker (soporte offline)
└── icons/
    ├── icon-72.png
    ├── icon-96.png
    ├── icon-128.png
    ├── icon-144.png
    ├── icon-152.png
    ├── icon-192.png   ← El más importante
    ├── icon-384.png
    └── icon-512.png   ← El más grande (Play Store / splash screen)
```

---

## 🚀 Cómo publicarla GRATIS

### Opción 1 — GitHub Pages (recomendada, 5 minutos)

1. Crea una cuenta en [github.com](https://github.com) si no tienes.
2. Crea un repositorio nuevo (ej: `wambra-app`).
3. Sube todos los archivos de esta carpeta al repositorio.
4. Ve a **Settings → Pages → Source → main branch → Save**.
5. Tu app estará en: `https://tu-usuario.github.io/wambra-app/`

> ✅ HTTPS automático (requerido para PWA) · Gratuito · Sin límite de uso

---

### Opción 2 — Netlify (drag & drop, 2 minutos)

1. Ve a [netlify.com](https://netlify.com) y crea una cuenta.
2. En el dashboard, arrastra **toda la carpeta** `wambra-app/` al área de deploy.
3. Listo. Netlify te da una URL tipo `https://wambra-xyz.netlify.app`.

> ✅ HTTPS automático · Dominio personalizable gratis · Muy fácil

---

### Opción 3 — Vercel (también muy fácil)

1. Ve a [vercel.com](https://vercel.com).
2. Conecta tu repositorio de GitHub o arrastra la carpeta.
3. Deploy automático.

---

## 📱 Cómo instalarla en el celular

### Android (Chrome)
1. Abre la URL de tu app en Chrome.
2. Aparece automáticamente el banner "Instalar WAMBRA" en la pantalla.
3. Toca **Instalar** y confirma.
4. La app aparece en tu pantalla de inicio como ícono.

### iPhone / iPad (Safari)
1. Abre la URL en **Safari** (no Chrome en iOS).
2. Toca el botón de **Compartir** (el cuadrado con flecha ↑).
3. Toca **"Agregar a pantalla de inicio"**.
4. Confirma con **Agregar**.

---

## ⚙️ Qué se agregó para hacerla app

| Archivo / Cambio | Para qué sirve |
|---|---|
| `manifest.json` | Le dice al navegador el nombre, ícono, colores y modo de pantalla de la app |
| `sw.js` | Service Worker: permite que funcione **sin internet** y cachea todos los archivos |
| Meta tags iOS | Apple ignora el manifest estándar; estos tags le dicen a Safari cómo mostrarla |
| Meta tags Windows | Para Edge y pantalla de inicio de Windows |
| `icons/` (8 tamaños) | Íconos para cada dispositivo y resolución |
| Banner de instalación | Aparece automáticamente en Android cuando la app es instalable |
| Meta OG / SEO | Para que se vea bien al compartir el link en WhatsApp o redes |

---

## ✅ Checklist antes de publicar

- [ ] Todos los archivos en la misma carpeta
- [ ] Publicada en un servidor con **HTTPS** (GitHub Pages / Netlify / Vercel = automático)
- [ ] Abrir con Chrome/Safari y verificar que aparezca el banner de instalar
- [ ] En DevTools → Application → Manifest: sin errores en rojo
- [ ] En DevTools → Application → Service Workers: estado "activated and running"

---

## 🛠️ Herramientas para verificar

- **Lighthouse** (Chrome DevTools → pestaña Lighthouse → PWA): puntaje de instalabilidad
- **PWA Builder** en [pwabuilder.com](https://pwabuilder.com): análisis completo y empaquetado para stores

---

Hecho con 💜 para jóvenes ecuatorianos.
